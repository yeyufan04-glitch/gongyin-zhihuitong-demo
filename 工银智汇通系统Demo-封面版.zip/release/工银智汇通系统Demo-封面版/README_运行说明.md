# 工银智汇通系统 Demo｜封面版

这是在原有系统 Demo 上增加产品封面页后的静态网页包。打开后先看到产品宣传页，点击“进入系统”即可进入原有企业端首页；原有企业客户、银行经办、银行复核和系统运行页面继续保留。

## 运行方式

- 直接双击 `index.html`；
- macOS / Linux 可运行 `启动预览.command`；
- Windows 可运行 `启动预览.bat`。

网页包不需要 Node.js、npm、数据库、API Key 或 ChatGPT 账号。发布到其他平台时，请保持 `index.html`、`assets/`、`data/`、`demo-data/`、`demo-documents/`、`images/` 和 `favicon.svg` 的相对位置不变。

## 数据边界

- SWIFT、银行风险系统和外部数据均为竞赛演示用模拟数据；
- 原始单据扫描件仅作为演示证据，不代表真实客户资料；
- 系统不连接真实工行核心、SWIFT、海关或风险系统；
- AI只提供整理、比对和提示，不直接触发真实入账。

@echo off
setlocal
cd /d "%~dp0"
set PORT=8765
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 goto launch_py
where python >nul 2>nul
if %ERRORLEVEL% EQU 0 goto launch_python
echo 未找到 Python 3。请直接双击 index.html，或安装 Python 3 后重新运行。
pause
exit /b 1
:launch_py
start "工银智汇通系统 Demo" "http://127.0.0.1:%PORT%/"
py -m http.server %PORT%
exit /b 0
:launch_python
start "工银智汇通系统 Demo" "http://127.0.0.1:%PORT%/"
python -m http.server %PORT%
exit /b 0

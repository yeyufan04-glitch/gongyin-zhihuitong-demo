#!/bin/sh
set -eu
cd "$(dirname "$0")"
PORT=8765
if command -v python3 >/dev/null 2>&1; then
  python3 -m http.server "$PORT" >/tmp/gongyin-zhihuitong-demo-http.log 2>&1 &
  SERVER_PID=$!
elif command -v python >/dev/null 2>&1; then
  python -m http.server "$PORT" >/tmp/gongyin-zhihuitong-demo-http.log 2>&1 &
  SERVER_PID=$!
else
  echo "未找到 Python 3。请直接双击 index.html，或安装 Python 3 后重新运行。"
  exit 1
fi
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
open "http://127.0.0.1:$PORT/" 2>/dev/null || true
echo "系统已启动：http://127.0.0.1:$PORT/"
echo "关闭此窗口即可停止预览。"
wait "$SERVER_PID"
